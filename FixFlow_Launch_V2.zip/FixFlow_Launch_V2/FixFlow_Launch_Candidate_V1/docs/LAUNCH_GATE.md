# FixFlow Launch Candidate V1

## Required before public paid launch
- Deploy backend behind HTTPS
- Configure PostgreSQL and automated backups
- Enable tenant isolation tests
- Configure production auth/JWT secrets
- Configure email/SMS provider and verify delivery
- Connect an approved payment provider and verify webhook signatures
- Run end-to-end checkout in provider test mode
- Run security checks and dependency audit
- Add Privacy Policy, Terms, refund/cancellation policy
- Verify mobile technician workflow
- Complete 5-company beta acceptance test

## Core acceptance flow
Customer request -> AI intake -> Job -> Schedule -> Technician -> Quote -> Approval -> Invoice -> Payment -> Notification -> Review request

## Release rule
Do not enable real-money payments or advertise the product as fully production-ready until the payment provider has approved the business/account and all production checks above pass.
