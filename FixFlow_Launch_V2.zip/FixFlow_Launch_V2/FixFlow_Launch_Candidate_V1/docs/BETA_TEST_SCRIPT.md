# 30-minute beta test
1. Create company account.
2. Add customer.
3. Submit a customer request.
4. Confirm AI classification and create job.
5. Schedule and assign technician.
6. Create/send quote and approve it.
7. Create invoice.
8. Open customer payment link in test/manual mode.
9. Mark/receive test payment and verify invoice status.
10. Verify notification events.
11. Log in as a second company and confirm no first-company data is visible.
12. Test technician status update from mobile.
