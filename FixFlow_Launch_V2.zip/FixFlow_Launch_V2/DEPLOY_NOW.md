# FixFlow — Deploy Now

## Order
1. Provision PostgreSQL.
2. Set production environment variables.
3. Deploy Node/Express backend.
4. Serve the frontend over HTTPS.
5. Run database migrations.
6. Create the first company/admin account.
7. Run the end-to-end beta test.
8. Keep payments in manual/test mode until a provider approves the business and webhook flow.

## Production gate
- HTTPS enabled
- JWT/session secrets replaced
- CORS restricted to production domain
- Database backups enabled
- Rate limiting enabled
- Tenant isolation verified
- Payment webhooks signature-verified before live money
- No secret keys committed to source control
- Error logging/monitoring enabled

## Beta acceptance
Customer -> AI intake -> Job -> Technician -> Schedule -> Quote -> Approval -> Invoice -> Test Payment -> Notification.

Do not market live payment processing as available until the selected payment provider has approved the account and the live webhook/payout flow has passed testing.
