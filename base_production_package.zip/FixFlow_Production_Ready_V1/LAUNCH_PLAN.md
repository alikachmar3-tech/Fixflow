# Fast Launch Plan

Day 1: deploy backend + database, configure auth and tenant isolation.
Day 2: run end-to-end workflow and security tests.
Day 3: configure communications and test payment mode.
Day 4: onboard first 2 beta companies.
Day 5: onboard 3 more, fix only critical blockers.

Release rule: do not enable live payments until the payment provider has explicitly approved the FixFlow business model and account structure.
