# FixFlow Production Acceptance Checklist

## Account & tenancy
- [ ] Signup works
- [ ] Login works
- [ ] Passwords are hashed
- [ ] Session/JWT expiry works
- [ ] Company A cannot read Company B data
- [ ] Company A cannot modify Company B data

## Core workflow
- [ ] Create customer
- [ ] Create job
- [ ] AI intake classifies request
- [ ] Human confirms AI-created job
- [ ] Schedule technician
- [ ] Prevent double booking
- [ ] Create quote
- [ ] Customer approves quote
- [ ] Create invoice
- [ ] Customer opens payment link
- [ ] Test payment marks invoice paid
- [ ] Payment webhook is verified before state change
- [ ] Payment receipt/status is shown

## Notifications
- [ ] Booking confirmation
- [ ] Appointment reminder
- [ ] Technician alert
- [ ] Quote notification
- [ ] Invoice reminder
- [ ] Payment confirmation
- [ ] Review request

## Security
- [ ] HTTPS only
- [ ] CORS restricted
- [ ] Rate limiting enabled
- [ ] Security headers enabled
- [ ] Secrets stored in environment variables
- [ ] Webhook signatures verified
- [ ] Audit/error logs enabled
- [ ] Database backups configured

## Launch
- [ ] Domain connected
- [ ] Pricing page
- [ ] Terms of Service
- [ ] Privacy Policy
- [ ] Support email
- [ ] 14-day trial configured
- [ ] Starter/Growth/Pro billing configured
- [ ] 5 beta companies invited
